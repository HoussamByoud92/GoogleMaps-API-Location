package com.example.location_mobile;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private double latitude = 0.0;
    private double longitude = 0.0;
    private double altitude = 0.0;
    private float accuracy = 0.0f;
    private boolean locationReady = false;

    RequestQueue requestQueue;
    String insertUrl = "http://10.0.2.2/localisation/createPosition.php";

    Button btnAfficherMap;
    Button btnEnvoyerAfficher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAfficherMap = findViewById(R.id.btnAfficherMap);
        btnEnvoyerAfficher = findViewById(R.id.btnEnvoyerAfficher);

        requestQueue = Volley.newRequestQueue(getApplicationContext());
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                    1);
            return;
        }

        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 10, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                altitude = location.getAltitude();
                accuracy = location.getAccuracy();
                locationReady = true;

                String msg = String.format("Lat: %.6f, Lon: %.6f, Alt: %.2f, Acc: %.2f",
                        latitude, longitude, altitude, accuracy);
                Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {
                Toast.makeText(getApplicationContext(), provider + " Enabled", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onProviderDisabled(String provider) {
                Toast.makeText(getApplicationContext(), provider + " Disabled", Toast.LENGTH_SHORT).show();
            }
        });

        btnAfficherMap.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, MapsActivity.class);
            startActivity(intent);
        });

        btnEnvoyerAfficher.setOnClickListener(v -> {
            if (locationReady && latitude != 0.0 && longitude != 0.0) {
                addPosition(latitude, longitude);
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Location not ready yet!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    void addPosition(final double lat, final double lon) {
        StringRequest request = new StringRequest(Request.Method.POST,
                insertUrl,
                response -> {
                    Log.d("ServerResponse", response.toString());
                    Toast.makeText(getApplicationContext(), "Réponse: " + response, Toast.LENGTH_LONG).show();
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Erreur: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
        ) {

            @SuppressLint("HardwareIds")
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

                params.put("latitude", String.valueOf(lat));
                params.put("longitude", String.valueOf(lon));
                params.put("date", sdf.format(new Date()));
                String androidId = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
                params.put("imei", androidId);

                return params;
            }
        };

        requestQueue.add(request);
    }
}
